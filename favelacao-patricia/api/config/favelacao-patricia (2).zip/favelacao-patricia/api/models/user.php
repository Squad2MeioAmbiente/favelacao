<?php 

class User {
    private $conn;
    private $nomeTabela = "usuarios";

    public $id;
    public $nome;
    public $dataNascimento;
    public $email;
    public $telefone;
    public $senha;
    public $confirmarSenha;
    public $apelido;
    public $imgAvatar;

    public function __construct($db) {
        $this->conn = $db;
    }

   
function read(){
    $sql= "SELECT * from "  . $this->nomeTabela;

    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    return $stmt;
}


function delete(){
    
    $sql = "DELETE FROM " . $this->nomeTabela . " WHERE id = ?";
  
    $stmt = $this->conn->prepare($sql);
  
    $this->id=htmlspecialchars(strip_tags($this->id));
  
    $stmt->bindParam(1, $this->id);
  
    if($stmt->execute()){
        return true;
    }
  
    return false;
}

}

?>