<?php
    //session_start();

    $servername = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $database = "favelacao"; 
    $conn = mysqli_connect($servername, $username, $password, $database); 

    if(($_POST['nome'] != "") && ($_POST['dataNascimento'] != "")
    && ($_POST['email'] != "") && ($_POST['apelido'] != "")){ 
        
        $nome =$_POST['nome'];
        $dataNascimento =$_POST['dataNascimento']; 
        $email =$_POST['email'];
        $apelido =$_POST['apelido'];

        //$id = "SELECT id FROM usuarios WHERE `email`= '$email'";
        // $results = mysqli_query($conn, $id); 
        
        $sql = "UPDATE usuarios SET `nome`= '$nome', `dataNascimento` = '$dataNascimento', `email`= '$email', `apelido` = '$apelido'  WHERE (`id` = '1')";
        $result = mysqli_query($conn, $sql); 
        
        if($result){ 
            echo "<script>
            alert ('Dados atualizados com sucesso!')
            window.location.href='http://localhost/favelacao/frontend/jogo/screen1/s1.html'
        </script>";
        }
        else{ 
            echo "<script>
            alert ('Dados não atualizados!')
            window.location.href='http://localhost/favelacao/frontend/perfil/perfil.php'
        </script>";
        } 
        
    }
    else{
        echo "<script>
                alert ('Por favor, preencha todos os campos')
                window.location.href='http://localhost/favelacao/frontend/perfil/perfil.php'
            </script>";
    } 
    
?> 