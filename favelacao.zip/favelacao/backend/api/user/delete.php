<?php
    $servername = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $database = "favelacao"; 
    $conn = mysqli_connect($servername, $username, $password, $database); 
        
        
    
    $sql = "DELETE  from usuarios  WHERE (`id` = '2')";

    $result = mysqli_query($conn, $sql); 
        if($result){ 
            echo "Conta Apagada com sucesso!!!"; 
        }
        else{ 
            echo "Conta não inserida!";
        } 
    
    
?> 