<?php
    $servername = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $database = "favelacao"; 
    $conn = mysqli_connect($servername, $username, $password, $database); 

    if((isset($_POST['nome'])) && (strlen($_POST['senha'])==8)){ 
        
        $nome =$_POST['nome'];
        $dataNascimento =$_POST['dataNascimento']; 
        $email =$_POST['email'];
        $telefone =$_POST['telefone'];
        $senha =$_POST['senha'];
        $confirmarSenha =$_POST['confirmarSenha'];
        $apelido =$_POST['apelido'];
        $imgAvatar =$_POST['imgAvatar'];

        
        $sql = "insert into usuarios (nome, dataNascimento, email, telefone, senha, confirmarSenha, apelido, imgAvatar) values ('$nome', '$dataNascimento', '$email', '$telefone', '$senha', '$confirmarSenha', '$apelido', '$imgAvatar' )"; 
        $result = mysqli_query($conn, $sql); 
        if($result){ 
            echo "<script>
                alert ('Dados inseridos com sucesso!')
                window.location.href='http://localhost/favelacao/frontend/login.php'
            </script>";
        }
        else{ 
            echo "<script>
                alert ('Dados não inseridos!')
                window.location.href=''
            </script>";
        } 
        
    }
    else{
        echo "<script>
                alert ('Por favor, preencha todos os campos!')
                window.location.href='http://localhost/favelacao/frontend/cadastro.php'
            </script>";
    } 
    
?>  