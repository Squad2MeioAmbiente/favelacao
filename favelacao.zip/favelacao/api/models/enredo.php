<?php 

class Enredo {
    private $conn;
    private $nomeTabela = "enredo";

    public $idenredo;
    public $frase;


    public function __construct($db) {
        $this->conn = $db;
    }

   
function read(){
    $sql= "SELECT * from "  . $this->nomeTabela;

    $stmt = $this->conn->prepare($sql);
    $stmt->execute();

    return $stmt;
}

function readOne(){
  
    $sql = "SELECT * FROM " . $this->nomeTabela . " WHERE idenredo = ? LIMIT 0,1";
  
    $stmt = $this->conn->prepare( $sql );
  
    $stmt->bindParam(1, $this->idenredo);
  
    $stmt->execute();
  

    $row = $stmt->fetch(PDO::FETCH_ASSOC);
  
    $this->idenredo = $row['idenredo'];
    $this->frase = $row['frase'];
  
}

}

?>