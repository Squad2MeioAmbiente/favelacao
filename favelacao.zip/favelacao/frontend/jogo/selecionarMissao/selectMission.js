var teste = "TRUE"
console.log("teste")
function jsFunction () {
    var ancora = document.getElementById("testando")
console.log(ancora)

if (teste ==="TRUE"){
    console.log("é true")
    ancora.href = "https://getbootstrap.com/docs/4.0/components/card/"
}
else {
    console.log("É FALSE")
}

}

