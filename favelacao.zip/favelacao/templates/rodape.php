<footer class="rodape">
    <a href="https://instagram.com/">
      <img class="iconInstagram" src="./frontend/img/instagram.svg" alt="Instagram"> 
    </a>
    <a href="https://github.com/">
      <img class="iconGit" src="./frontend/img/logotipo-do-github.svg" alt="GitHub">
    </a>
    <a href="https://www.instagram.com/">
      <img class="iconInstagram" src="./frontend/img/facebook.svg" alt="Facebook">
    </a> 
    <span>FavelAção 2021</span>
</footer>